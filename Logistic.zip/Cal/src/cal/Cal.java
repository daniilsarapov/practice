/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cal;

/**
 *
 * @author Dan
 */

import java.util.Scanner;  

public class Cal {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Автор - Сарапов Даниил ДКИП-482
        System.out.println("make num 1:");
        double num1 = scanner.nextDouble();


        System.out.println("select operation (+, -, *, /):");
        char operator = scanner.next().charAt(0);

    
        System.out.println("make num 2:");
        double num2 = scanner.nextDouble();

       
        double result = 0;


        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    System.out.println("error");
                    return;
                }
                break;
            default:
                System.out.println("error");
                return;
        }

   
        System.out.println("result: " + result);
    }
}

