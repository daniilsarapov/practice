package logistic;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.Graphics;
import java.awt.Image;
import javax.imageio.ImageIO;
import java.io.IOException;

/**
 *
 * @author Dan
 */
public class Logistic extends JFrame {

    private static Logistic logistic_logistic;
    private static Image road;
    private static Image bus;
    private static Image van;
    private static Image explosion;
    private static double[] bus_x = {-200, -600}; // Начальные позиции автобусов (слева направо)
    private static double[] van_x = {900, 1300};  // Начальные позиции грузовиков (справа налево)
    private static long last_frame_time;
    private static float speed = 200; // Скорость движения
    private static int object_width = 150;  // Уменьшенная ширина объектов
    private static int object_height = 75;  // Уменьшенная высота объектов

    public static void main(String[] args) throws IOException {
        road = ImageIO.read(Logistic.class.getResourceAsStream("road.jpg"));
        bus = ImageIO.read(Logistic.class.getResourceAsStream("bus.jpg"));
        van = ImageIO.read(Logistic.class.getResourceAsStream("van.jpg"));
        explosion = ImageIO.read(Logistic.class.getResourceAsStream("explosion.png")); // Изображение взрыва

        logistic_logistic = new Logistic();
        logistic_logistic.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        logistic_logistic.setLocation(200, 50);
        logistic_logistic.setSize(900, 600);
        logistic_logistic.setResizable(false);

        LogisticField logistic_field = new LogisticField();
        logistic_logistic.add(logistic_field);

        logistic_logistic.setVisible(true);
        last_frame_time = System.nanoTime();
    }

    public static void onRepaint(Graphics g) {
        long current_time = System.nanoTime();
        float delta_time = (current_time - last_frame_time) * 0.000000001f;
        last_frame_time = current_time;

        // Движение автобусов (слева направо)
        for (int i = 0; i < bus_x.length; i++) {
            bus_x[i] += speed * delta_time;
            if (bus_x[i] > logistic_logistic.getWidth()) {
                bus_x[i] = -object_width;  // Сбрасываем автобус за левую границу
            }
        }

        // Движение грузовиков (справа налево)
        for (int i = 0; i < van_x.length; i++) {
            van_x[i] -= speed * delta_time;
            if (van_x[i] < -object_width) {
                van_x[i] = logistic_logistic.getWidth();  // Сбрасываем грузовик за правую границу
            }
        }

        // Рисуем фон, растягивая изображение на весь экран
        g.drawImage(road, 0, 0, logistic_logistic.getWidth(), logistic_logistic.getHeight(), null);

        // Проверяем столкновения и рисуем объекты
        for (int i = 0; i < bus_x.length; i++) {
            boolean collision = checkCollision((int) bus_x[i], logistic_logistic.getHeight() / 2 + object_height * (1 + i),
                    (int) van_x[i], logistic_logistic.getHeight() / 2 - object_height * (2 + i));

            if (collision) {
                // Рисуем взрыв на месте столкновения
                g.drawImage(explosion, (int) bus_x[i], logistic_logistic.getHeight() / 2, object_width, object_height, null);
            } else {
                // Рисуем грузовик и автобус с уменьшенными размерами, если нет столкновения
                g.drawImage(van, (int) van_x[i], logistic_logistic.getHeight() / 2 - object_height * (2 + i), object_width, object_height, null);
                g.drawImage(bus, (int) bus_x[i], logistic_logistic.getHeight() / 2 + object_height * (1 + i), object_width, object_height, null);
            }
        }
    }

    // Проверка на столкновение
    public static boolean checkCollision(int bus_x, int bus_y, int van_x, int van_y) {
        // Простая проверка пересечения прямоугольников автобуса и грузовика
        return Math.abs(bus_x - van_x) < object_width && Math.abs(bus_y - van_y) < object_height;
    }

    public static class LogisticField extends JPanel {
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            onRepaint(g);
            repaint();
        }
    }
}
